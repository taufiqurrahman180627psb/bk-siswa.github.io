-- Import via phpMyAdmin (tab Import). Database dibuat otomatis.
CREATE DATABASE IF NOT EXISTS bk_siswa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bk_siswa;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS users,tahun_pelajaran,kelas,siswa,jenis_pelanggaran,pelanggaran,prestasi,catatan,pembinaan,rekomendasi,konseling,panggilan,pengaturan;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(100) NOT NULL,username VARCHAR(50) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,role ENUM('admin','kesiswaan','wali_kelas') NOT NULL,no_hp VARCHAR(20),aktif TINYINT(1) NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB;
CREATE TABLE tahun_pelajaran(id INT AUTO_INCREMENT PRIMARY KEY,nama VARCHAR(20) NOT NULL,semester ENUM('Ganjil','Genap') NOT NULL,aktif TINYINT(1) NOT NULL DEFAULT 0) ENGINE=InnoDB;
CREATE TABLE kelas(id INT AUTO_INCREMENT PRIMARY KEY,nama_kelas VARCHAR(30) NOT NULL,tingkat VARCHAR(5),tahun_id INT,wali_id INT NULL,FOREIGN KEY(tahun_id) REFERENCES tahun_pelajaran(id) ON DELETE SET NULL,FOREIGN KEY(wali_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE siswa(id INT AUTO_INCREMENT PRIMARY KEY,nis VARCHAR(20) NOT NULL UNIQUE,nisn VARCHAR(20),nama VARCHAR(100) NOT NULL,jk ENUM('L','P') NOT NULL,tempat_lahir VARCHAR(60),tgl_lahir DATE,alamat TEXT,nama_ortu VARCHAR(100),hp_ortu VARCHAR(20),kelas_id INT NULL,tahun_id INT NULL,status ENUM('aktif','lulus','pindah','keluar') NOT NULL DEFAULT 'aktif',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(kelas_id),FOREIGN KEY(kelas_id) REFERENCES kelas(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE jenis_pelanggaran(id INT AUTO_INCREMENT PRIMARY KEY,kode VARCHAR(10) NOT NULL UNIQUE,nama VARCHAR(150) NOT NULL,kategori ENUM('Ringan','Sedang','Berat') NOT NULL,poin INT NOT NULL DEFAULT 0,tindakan_default VARCHAR(150)) ENGINE=InnoDB;
CREATE TABLE pelanggaran(id INT AUTO_INCREMENT PRIMARY KEY,siswa_id INT NOT NULL,jenis_id INT NOT NULL,tahun_id INT NULL,tanggal DATE NOT NULL,keterangan TEXT,bukti VARCHAR(255),poin INT NOT NULL DEFAULT 0,status ENUM('Tercatat','Diperiksa','Ditindaklanjuti','Selesai') NOT NULL DEFAULT 'Tercatat',tindak_lanjut ENUM('Teguran','Pembinaan','Konseling','Panggilan Orang Tua','Tindakan Lain') NULL,catatan_kesiswaan TEXT,pencatat_id INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(tanggal),FOREIGN KEY(siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,FOREIGN KEY(jenis_id) REFERENCES jenis_pelanggaran(id),FOREIGN KEY(pencatat_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE prestasi(id INT AUTO_INCREMENT PRIMARY KEY,siswa_id INT NOT NULL,nama_prestasi VARCHAR(150) NOT NULL,tingkat ENUM('Sekolah','Kecamatan','Kabupaten/Kota','Provinsi','Nasional','Internasional') NOT NULL,tanggal DATE NOT NULL,poin INT NOT NULL DEFAULT 0,tahun_id INT NULL,pencatat_id INT NULL,FOREIGN KEY(siswa_id) REFERENCES siswa(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE catatan(id INT AUTO_INCREMENT PRIMARY KEY,siswa_id INT NOT NULL,tanggal DATE NOT NULL,jenis ENUM('Akademik','Perilaku','Sosial','Kesehatan','Lainnya') NOT NULL,isi TEXT NOT NULL,pencatat_id INT NULL,FOREIGN KEY(siswa_id) REFERENCES siswa(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE pembinaan(id INT AUTO_INCREMENT PRIMARY KEY,siswa_id INT NOT NULL,pelanggaran_id INT NULL,tanggal DATE NOT NULL,jenis ENUM('Ringan','Sedang','Khusus') NOT NULL,uraian TEXT,hasil TEXT,status ENUM('Berjalan','Monitoring','Selesai','Perlu Tindak Lanjut') NOT NULL DEFAULT 'Berjalan',pembina_id INT NULL,FOREIGN KEY(siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,FOREIGN KEY(pelanggaran_id) REFERENCES pelanggaran(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE rekomendasi(id INT AUTO_INCREMENT PRIMARY KEY,siswa_id INT NOT NULL,tanggal DATE NOT NULL,alasan TEXT NOT NULL,status ENUM('Baru','Diterima','Dijadwalkan','Ditolak') NOT NULL DEFAULT 'Baru',wali_id INT NULL,FOREIGN KEY(siswa_id) REFERENCES siswa(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE konseling(id INT AUTO_INCREMENT PRIMARY KEY,siswa_id INT NOT NULL,rekomendasi_id INT NULL,tanggal DATE NOT NULL,permasalahan TEXT,hasil TEXT,tindakan TEXT,rtl TEXT,status ENUM('Proses','Monitoring','Selesai') NOT NULL DEFAULT 'Proses',konselor_id INT NULL,FOREIGN KEY(siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,FOREIGN KEY(rekomendasi_id) REFERENCES rekomendasi(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE panggilan(id INT AUTO_INCREMENT PRIMARY KEY,siswa_id INT NOT NULL,pelanggaran_id INT NULL,no_surat VARCHAR(50),tanggal_surat DATE NOT NULL,tanggal_hadir DATE NULL,perihal VARCHAR(200),hasil TEXT,status ENUM('Dibuat','Dikirim','Hadir','Tidak Hadir') NOT NULL DEFAULT 'Dibuat',pembuat_id INT NULL,FOREIGN KEY(siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,FOREIGN KEY(pelanggaran_id) REFERENCES pelanggaran(id) ON DELETE SET NULL) ENGINE=InnoDB;
CREATE TABLE pengaturan(kunci VARCHAR(50) PRIMARY KEY,nilai TEXT) ENGINE=InnoDB;

-- Seed (password semua akun: password)
INSERT INTO users(nama,username,password,role) VALUES
('Administrator','admin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin'),
('Guru Kesiswaan','kesiswaan','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','kesiswaan'),
('Wali Kelas X-1','wali1','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','wali_kelas');
INSERT INTO tahun_pelajaran(nama,semester,aktif) VALUES('2026/2027','Ganjil',1);
INSERT INTO kelas(nama_kelas,tingkat,tahun_id,wali_id) VALUES('X-1','X',1,3),('X-2','X',1,NULL);
INSERT INTO siswa(nis,nisn,nama,jk,nama_ortu,hp_ortu,kelas_id,tahun_id) VALUES
('1001','0011','Ahmad Fauzi','L','Bpk. Fauzi','081200000001',1,1),('1002','0012','Siti Aisyah','P','Ibu Aisyah','081200000002',1,1),('1003','0013','Budi Santoso','L','Bpk. Santoso','081200000003',2,1);
INSERT INTO jenis_pelanggaran(kode,nama,kategori,poin,tindakan_default) VALUES
('R01','Terlambat masuk sekolah','Ringan',5,'Teguran'),('R02','Seragam tidak sesuai','Ringan',5,'Teguran'),('R03','Tidak membawa perlengkapan','Ringan',3,'Teguran'),
('S01','Membolos / alpa','Sedang',15,'Pembinaan'),('S02','Membawa HP saat KBM','Sedang',10,'Pembinaan'),('S03','Berkelahi ringan','Sedang',25,'Konseling'),
('B01','Merokok di sekolah','Berat',40,'Panggilan Orang Tua'),('B02','Perundungan (bullying)','Berat',50,'Konseling'),('B03','Membawa senjata tajam / miras','Berat',100,'Panggilan Orang Tua');
INSERT INTO pengaturan VALUES('nama_sekolah','SMA Negeri Contoh'),('alamat_sekolah','Jl. Pendidikan No. 1, Surabaya'),('kepala_sekolah','Drs. Nama Kepala Sekolah'),
('batas_pembinaan','25'),('batas_panggilan','50'),('batas_sp','75'),('batas_berat','100');
