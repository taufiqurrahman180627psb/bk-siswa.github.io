<?php
function flash($m=null){if($m){$_SESSION['fl']=$m;return;}$x=$_SESSION['fl']??'';unset($_SESSION['fl']);return $x;}
function go($m,$x=''){header("Location: index.php?m=$m$x");exit;}
function tbl($rows,$cols){echo "<div class=tw><table><tr>";foreach($cols as $l)echo "<th>".e($l)."</th>";echo "</tr>";foreach($rows as $r){echo "<tr>";foreach($cols as $k=>$l)echo "<td>".e($r[$k]??'')."</td>";echo "</tr>";}if(!$rows)echo "<tr><td colspan=".count($cols).">Belum ada data</td></tr>";echo "</table></div>";}
function crud($c){
 $m=$_GET['m'];$t=$c['t'];$a=$_GET['a']??'list';$id=(int)($_GET['id']??0);$P=$_SERVER['REQUEST_METHOD']=='POST';$r=me()['role'];
 $rw=in_array($r,$c['rw']);$del=in_array($r,$c['del']??$c['rw']);
 $F=array_filter($c['f'],fn($d)=>empty($d[3])||in_array($r,$d[3]));
 if($id&&!q($c['sel']." WHERE ".$c['w']." AND $t.id=?",[...$c['p'],$id])->fetch())die('Data tidak ditemukan / bukan akses Anda');
 if($P&&$a=='del'){if(!$del)die('Akses ditolak');q("DELETE FROM $t WHERE id=?",[$id]);flash('Data dihapus');go($m);}
 if($P&&$a=='save'){if(!$rw)die('Akses ditolak');$v=[];
  foreach($F as $k=>$d){$x=trim($_POST[$k]??'');if($d[1]=='password'){if($x==='')continue;$x=password_hash($x,PASSWORD_DEFAULT);}
   if($x===''){if(!$id)continue;$x=null;}$v[$k]=$x;}
  if(isset($c['before']))$v=$c['before']($v,$id);
  if($id)q("UPDATE $t SET ".implode(',',array_map(fn($k)=>"`$k`=?",array_keys($v)))." WHERE id=?",[...array_values($v),$id]);
  else{$v+=$c['x']??[];q("INSERT INTO $t(".implode(',',array_map(fn($k)=>"`$k`",array_keys($v))).") VALUES(".implode(',',array_fill(0,count($v),'?')).")",array_values($v));}
  flash('Data tersimpan');go($m);}
 if($a=='form'&&$rw){$row=$id?q("SELECT * FROM $t WHERE id=?",[$id])->fetch():[];
  echo "<h2>".($id?'Edit':'Tambah')." {$c['title']}</h2><form method=post action='index.php?m=$m&a=save&id=$id' class=card>".csrf();
  foreach($F as $k=>$d){$req=str_ends_with($d[0],'*')?'required':'';$val=(string)($row[$k]??$_GET[$k]??'');echo "<label>".e($d[0])."</label>";
   if($d[1]=='textarea')echo "<textarea name=$k rows=3 $req>".e($val)."</textarea>";
   elseif($d[1]=='select'){$o=$d[2];$o=is_string($o)?q($o)->fetchAll(PDO::FETCH_NUM):array_map(fn($x)=>[$x,$x],$o);
    echo "<select name=$k $req><option value=''>-</option>";foreach($o as [$ov,$ol])echo "<option value='".e($ov)."'".((string)$ov===$val?' selected':'').">".e($ol)."</option>";echo "</select>";}
   elseif($d[1]=='password')echo "<input type=password name=$k autocomplete=new-password>";
   else echo "<input type='{$d[1]}' name=$k value='".e($val)."' $req>";}
  echo "<p><button class=b>Simpan</button> <a class='b g' href='index.php?m=$m'>Batal</a></p></form>";return;}
 $s=trim($_GET['s']??'');$w=$c['w'];$p=$c['p'];
 if($s!==''&&!empty($c['cari'])){$w.=" AND CONCAT_WS(' ',{$c['cari']}) LIKE ?";$p[]="%$s%";}
 $rows=q($c['sel']." WHERE $w ORDER BY ".$c['ord']." LIMIT 500",$p)->fetchAll();
 echo "<h2>{$c['title']}</h2><p class=np>".($rw?"<a class=b href='index.php?m=$m&a=form'>+ Tambah</a> ":'').($rw&&!empty($c['import'])?"<a class='b g' href='index.php?m=import'>Import Excel</a>":'')."</p>";
 if(!empty($c['cari']))echo "<form class=np style='margin-bottom:10px'><input type=hidden name=m value=$m><input name=s value='".e($s)."' placeholder='Cari...' style='width:240px'> <button class=b>Cari</button></form>";
 echo "<div class=tw><table><tr>";foreach($c['cols'] as $l)echo "<th>".e($l)."</th>";echo "<th class=np>Aksi</th></tr>";
 foreach($rows as $x){echo "<tr>";foreach($c['cols'] as $k=>$l){$val=e($x[$k]??'');
   if(($k=='siswa'&&isset($x['sid']))||($t=='siswa'&&$k=='nama'))$val="<a href='index.php?m=profil&id=".($x['sid']??$x['id'])."'>$val</a>";echo "<td>$val</td>";}
  echo "<td class=np>";if(isset($c['link']))echo "<a class='b g' target=_blank href='index.php?m={$c['link'][1]}&id={$x['id']}'>{$c['link'][0]}</a> ";
  if($rw)echo "<a class=b href='index.php?m=$m&a=form&id={$x['id']}'>Edit</a> ";
  if($del)echo "<form method=post action='index.php?m=$m&a=del&id={$x['id']}' style=display:inline onsubmit=\"return confirm('Hapus data?')\">".csrf()."<button class='b r'>Hapus</button></form>";
  echo "</td></tr>";}
 if(!$rows)echo "<tr><td colspan=".(count($c['cols'])+1).">Belum ada data</td></tr>";echo "</table></div>";}
