<?php $r=me()['role'];$M=[
'admin'=>[['Dashboard','dashboard'],['Admin','users&s=admin'],['Kesiswaan','users&s=kesiswaan'],['Wali Kelas','users&s=wali_kelas'],['Data Siswa','siswa'],['Data Kelas','kelas'],['Tahun Pelajaran','tahun'],['Jenis Pelanggaran & Poin','jenis'],['Pengaturan Sistem','pengaturan'],['Monitoring','monitoring'],['Laporan','laporan']],
'kesiswaan'=>[['Dashboard','dashboard'],['Data Siswa','siswa'],['Input Pelanggaran','pelanggaran'],['Prestasi','prestasi'],['Pembinaan','pembinaan'],['Konseling','konseling'],['Rekomendasi Masuk','rekomendasi'],['Surat/Panggilan Ortu','panggilan'],['Monitoring Siswa','monitoring'],['Laporan','laporan']],
'wali_kelas'=>[['Dashboard','dashboard'],['Siswa Kelas Saya','siswa'],['Catatan Siswa','catatan'],['Pelanggaran','pelanggaran'],['Prestasi','prestasi'],['Pembinaan','pembinaan'],['Rekomendasi Konseling','rekomendasi'],['Monitoring Kelas','monitoring'],['Laporan Kelas','laporan']]][$r];?>
<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>BK Siswa</title>
<style>*{box-sizing:border-box}body{margin:0;font:14px system-ui;background:#f1f5f9;color:#0f172a}.w{display:flex;min-height:100vh}nav{width:230px;background:#0f172a;color:#cbd5e1;padding:14px;flex-shrink:0}nav a{display:block;color:#cbd5e1;text-decoration:none;padding:8px 10px;border-radius:6px}nav a:hover{background:#1e40af;color:#fff}main{flex:1;padding:20px;overflow:auto}
.card,.tw{background:#fff;border-radius:10px;padding:16px;margin-bottom:16px;box-shadow:0 1px 3px #0001}.tw{padding:0;overflow:auto}table{border-collapse:collapse;width:100%}th,td{padding:8px 10px;border-bottom:1px solid #e2e8f0;text-align:left}th{background:#f8fafc}
label{display:block;margin-top:10px;font-weight:600}input,select,textarea{width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:6px}.b{display:inline-block;padding:6px 12px;background:#1d4ed8;color:#fff;border:0;border-radius:6px;text-decoration:none;cursor:pointer;font-size:13px}.b.r{background:#dc2626}.b.g{background:#64748b}
.st{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}.st div{background:#fff;padding:14px;border-radius:10px}.st b{font-size:26px;display:block}.ok{background:#dcfce7;padding:8px;border-radius:6px;margin-bottom:10px}
@media(max-width:700px){.w{flex-direction:column}nav{width:100%}}@media print{nav,.np{display:none}}</style>
<div class=w><nav><b style="color:#fff">BK & Kesiswaan</b><div style="margin:4px 0 12px;font-size:12px"><?=e(me()['nama'])?> (<?=e($r)?>)</div>
<?php foreach($M as [$l,$u])echo "<a href='index.php?m=$u'>".e($l)."</a>";?>
<a href=logout.php style="margin-top:14px;background:#7f1d1d;color:#fff">Keluar</a></nav><main>
<?php if($f=flash())echo "<div class=ok>".e($f)."</div>";?>
