<?php
// pages/import.php - Import Data Siswa dari Excel (.xlsx) / CSV. Hanya admin.
const IMP_HEAD=['NIS','NISN','Nama','JK','Tempat Lahir','Tgl Lahir','Alamat','Nama Ortu','HP Ortu','Kelas'];

function xlsx_rows($f){
 $z=new ZipArchive;if($z->open($f)!==true)return null;
 $ss=[];
 if(($x=$z->getFromName('xl/sharedStrings.xml'))!==false){
  foreach(simplexml_load_string($x)->si as $si){
   if(isset($si->t))$ss[]=(string)$si->t;
   else{$t='';foreach($si->r as $run)$t.=(string)$run->t;$ss[]=$t;}
  }
 }
 $sx=$z->getFromName('xl/worksheets/sheet1.xml');
 if($sx===false){for($i=0;$i<$z->numFiles;$i++){$n=$z->getNameIndex($i);if(preg_match('~^xl/worksheets/[^/]+\.xml$~',$n)){$sx=$z->getFromIndex($i);break;}}}
 if($sx===false)return null;
 $rows=[];
 foreach(simplexml_load_string($sx)->sheetData->row as $row){
  $cells=[];
  foreach($row->c as $c){
   preg_match('/^[A-Z]+/',(string)$c['r'],$m);$col=0;
   foreach(str_split($m[0]) as $ch)$col=$col*26+ord($ch)-64;
   $col--;$t=(string)$c['t'];
   if($t=='s')$v=$ss[(int)$c->v]??'';
   elseif($t=='inlineStr')$v=(string)$c->is->t;
   else $v=(string)$c->v;
   $cells[$col]=trim($v);
  }
  if($cells){$o=[];for($i=0;$i<=max(array_keys($cells));$i++)$o[]=$cells[$i]??'';$rows[]=$o;}
 }
 return $rows;
}

function csv_rows($f){
 $s=file_get_contents($f);$s=preg_replace('/^\xEF\xBB\xBF/','',$s);
 if(!mb_check_encoding($s,'UTF-8'))$s=mb_convert_encoding($s,'UTF-8','Windows-1252');
 $lines=preg_split('/\r\n|\n|\r/',$s);
 if($lines&&stripos($lines[0],'sep=')===0)array_shift($lines);
 $first=$lines[0]??'';
 $d=';';$best=substr_count($first,';');
 foreach([','=>',',"\t"=>"\t"] as $c){if(substr_count($first,$c)>$best){$best=substr_count($first,$c);$d=$c;}}
 $h=fopen('php://temp','w+');fwrite($h,implode("\n",$lines));rewind($h);
 $rows=[];
 while(($r=fgetcsv($h,0,$d,'"','\\'))!==false){if(count($r)==1&&trim((string)$r[0])==='')continue;$rows[]=array_map(fn($x)=>trim((string)$x),$r);}
 fclose($h);return $rows;
}

function imp_tgl($v){
 $v=trim($v);if($v==='')return null;
 if(preg_match('/^\d{5}$/',$v))return date('Y-m-d',strtotime('1899-12-30 +'.(int)$v.' days'));
 if(preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/',$v,$m))return sprintf('%04d-%02d-%02d',$m[1],$m[2],$m[3]);
 if(preg_match('/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})$/',$v,$m))return sprintf('%04d-%02d-%02d',$m[3],$m[2],$m[1]);
 return false;
}

function imp_run($file,$upd){
 $ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
 if($ext=='xlsx'&&!class_exists('ZipArchive'))return ['err'=>'Ekstensi PHP zip belum aktif. Aktifkan extension=zip di php.ini, atau simpan file sebagai CSV.'];
 try{$rows=$ext=='xlsx'?xlsx_rows($file['tmp_name']):($ext=='csv'?csv_rows($file['tmp_name']):null);}
 catch(Throwable $t){$rows=null;}
 if(!$rows||count($rows)<2)return ['err'=>'File kosong / tidak terbaca. Gunakan .xlsx atau .csv sesuai template.'];
 $alias=['nis'=>'nis','nisn'=>'nisn','nama'=>'nama','nama siswa'=>'nama','jk'=>'jk','jenis kelamin'=>'jk','tempat lahir'=>'tempat_lahir','tgl lahir'=>'tgl_lahir','tanggal lahir'=>'tgl_lahir','alamat'=>'alamat','nama ortu'=>'nama_ortu','orang tua'=>'nama_ortu','nama orang tua'=>'nama_ortu','hp ortu'=>'hp_ortu','no hp ortu'=>'hp_ortu','hp orang tua'=>'hp_ortu','kelas'=>'kelas'];
 $map=[];
 foreach(array_shift($rows) as $i=>$h){
  $h=trim(preg_replace('/\s+/',' ',preg_replace('/[^a-z ]/','',str_replace(['_','.'],' ',strtolower($h)))));
  if(isset($alias[$h]))$map[$alias[$h]]=$i;
 }
 foreach(['nis','nama','jk'] as $k)if(!isset($map[$k]))return ['err'=>"Kolom wajib '$k' tidak ditemukan di baris header. Gunakan template."];
 $kls=[];foreach(q("SELECT id,nama_kelas FROM kelas")->fetchAll() as $k)$kls[strtolower(trim($k['nama_kelas']))]=$k['id'];
 $tid=tp()?:null;
 $res=['ok'=>0,'upd'=>0,'skip'=>0,'msg'=>[]];
 $db=db();$db->beginTransaction();
 foreach($rows as $n=>$r){
  $ln=$n+2;
  $g=fn($k)=>isset($map[$k])?trim((string)($r[$map[$k]]??'')):'';
  if(implode('',$r)==='')continue;
  $nis=$g('nis');$nama=$g('nama');$jk=strtoupper(substr($g('jk'),0,1));
  if($nis===''||$nama===''){$res['skip']++;$res['msg'][]="Baris $ln: NIS/Nama kosong, dilewati";continue;}
  if(!in_array($jk,['L','P'])){$res['skip']++;$res['msg'][]="Baris $ln ($nama): JK harus L/P, dilewati";continue;}
  $tgl=imp_tgl($g('tgl_lahir'));
  if($tgl===false){$res['msg'][]="Baris $ln ($nama): format tanggal lahir tidak dikenali, dikosongkan";$tgl=null;}
  $hp=$g('hp_ortu');if(preg_match('/^8\d{8,12}$/',$hp))$hp='0'.$hp; // nol di depan hilang di Excel
  $kid=null;
  if($g('kelas')!==''){$kid=$kls[strtolower($g('kelas'))]??null;if(!$kid)$res['msg'][]="Baris $ln ($nama): kelas '".$g('kelas')."' tidak ada di Data Kelas, kelas dikosongkan";}
  $v=['nisn'=>$g('nisn'),'nama'=>$nama,'jk'=>$jk,'tempat_lahir'=>$g('tempat_lahir'),'tgl_lahir'=>$tgl,'alamat'=>$g('alamat'),'nama_ortu'=>$g('nama_ortu'),'hp_ortu'=>$hp,'kelas_id'=>$kid];
  $v=array_map(fn($x)=>$x===''?null:$x,$v);
  try{
   $id=q("SELECT id FROM siswa WHERE nis=?",[$nis])->fetchColumn();
   if($id){
    if(!$upd){$res['skip']++;$res['msg'][]="Baris $ln ($nama): NIS $nis sudah ada, dilewati";continue;}
    $v=array_filter($v,fn($x)=>$x!==null);
    q("UPDATE siswa SET ".implode(',',array_map(fn($k)=>"`$k`=?",array_keys($v)))." WHERE id=?",[...array_values($v),$id]);
    $res['upd']++;
   }else{
    $v+=['nis'=>$nis,'tahun_id'=>$tid,'status'=>'aktif'];
    q("INSERT INTO siswa(".implode(',',array_map(fn($k)=>"`$k`",array_keys($v))).") VALUES(".implode(',',array_fill(0,count($v),'?')).")",array_values($v));
    $res['ok']++;
   }
  }catch(Throwable $t){$res['skip']++;$res['msg'][]="Baris $ln ($nama): gagal disimpan";}
 }
 $db->commit();
 return $res;
}

// ---- Download template ----
if(isset($_GET['tpl'])){
 $raw=true;
 header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename=template_siswa.csv');
 echo "\xEF\xBB\xBF";echo "sep=;\r\n";
 $o=fopen('php://output','w');
 fputcsv($o,IMP_HEAD,';','"','\\');
 fputcsv($o,['1004','0014','Contoh Siswa','L','Surabaya','2010-05-17','Jl. Mawar No. 1','Bpk. Contoh','081234567890','X-1'],';','"','\\');
 return;
}

$rep=null;
if($_SERVER['REQUEST_METHOD']=='POST'){
 if(empty($_FILES['file']['tmp_name'])||$_FILES['file']['error']!==UPLOAD_ERR_OK)$rep=['err'=>'Pilih file terlebih dahulu.'];
 else $rep=imp_run($_FILES['file'],!empty($_POST['upd']));
}

echo "<h2>Import Data Siswa dari Excel</h2><div class=card>
<p><b>Langkah:</b></p><ol>
<li><a class='b g' href='index.php?m=import&tpl=1'>Download Template</a> lalu buka dengan Excel.</li>
<li>Isi data siswa mulai baris ke-2 (jangan ubah judul kolom). Kolom wajib: <b>NIS, Nama, JK (L/P)</b>.</li>
<li>Kolom <b>Kelas</b> harus sama persis dengan nama di menu Data Kelas (mis. X-1).</li>
<li>Tanggal lahir: format <code>2010-05-17</code> atau <code>17/05/2010</code>.</li>
<li>Simpan sebagai <b>.xlsx</b> (atau CSV), lalu upload di bawah.</li></ol>
<p style='font-size:12px;color:#64748b'>Tip: format kolom NIS/NISN/HP sebagai <i>Text</i> di Excel agar angka 0 di depan tidak hilang.</p>
<form method=post enctype='multipart/form-data'>".csrf()."
<label>File Excel / CSV</label><input type=file name=file accept='.xlsx,.csv' required>
<label style='font-weight:400'><input type=checkbox name=upd value=1 style='width:auto'> Perbarui data jika NIS sudah ada (jika tidak dicentang, NIS yang sudah ada dilewati)</label>
<p><button class=b>Import</button> <a class='b g' href='index.php?m=siswa'>Kembali</a></p></form></div>";

if($rep){
 if(isset($rep['err']))echo "<div class=card style='background:#fee2e2'>".e($rep['err'])."</div>";
 else{
  echo "<div class=ok><b>Selesai.</b> Ditambahkan: {$rep['ok']} | Diperbarui: {$rep['upd']} | Dilewati: {$rep['skip']}</div>";
  if($rep['msg']){echo "<div class=card><b>Catatan:</b><ul>";foreach(array_slice($rep['msg'],0,100) as $m2)echo "<li>".e($m2)."</li>";echo "</ul></div>";}
 }
}
