<?php $n=fn($s,$p=[])=>q($s,$p)->fetchColumn();$t=tp();
$cards=[['Siswa aktif',$n("SELECT COUNT(*) FROM siswa WHERE status='aktif'$sc")],
['Pelanggaran TA aktif',$n("SELECT COUNT(*) FROM pelanggaran JOIN siswa ON siswa.id=pelanggaran.siswa_id WHERE $ws AND pelanggaran.tahun_id=?",[$t])],
['Belum ditindaklanjuti',$n("SELECT COUNT(*) FROM pelanggaran JOIN siswa ON siswa.id=pelanggaran.siswa_id WHERE $ws AND pelanggaran.status IN('Tercatat','Diperiksa')")],
['Rekomendasi baru',$n("SELECT COUNT(*) FROM rekomendasi JOIN siswa ON siswa.id=rekomendasi.siswa_id WHERE $ws AND rekomendasi.status='Baru'")],
['Konseling berjalan',$n("SELECT COUNT(*) FROM konseling JOIN siswa ON siswa.id=konseling.siswa_id WHERE $ws AND konseling.status<>'Selesai'")]];
echo "<h2>Dashboard</h2><div class=st>";foreach($cards as [$l,$v])echo "<div><b>$v</b>".e($l)."</div>";echo "</div><h3>Poin pelanggaran tertinggi (TA aktif)</h3>";
$rows=q("SELECT siswa.nama,kelas.nama_kelas kelas,COALESCE(SUM(pelanggaran.poin),0) poin FROM siswa LEFT JOIN kelas ON kelas.id=siswa.kelas_id LEFT JOIN pelanggaran ON pelanggaran.siswa_id=siswa.id AND pelanggaran.tahun_id=? WHERE $ws AND siswa.status='aktif' GROUP BY siswa.id ORDER BY poin DESC LIMIT 5",[$t])->fetchAll();
foreach($rows as &$x)$x['st']=statusPoin($x['poin']);tbl($rows,['nama'=>'Siswa','kelas'=>'Kelas','poin'=>'Poin','st'=>'Status']);
