<?php
// === EDIT KONEKSI DATABASE DI SINI ===
const DB_HOST='localhost',DB_USER='root',DB_PASS='',DB_NAME='bk_siswa';
session_start();
function db(){static $p;if(!$p)$p=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);return $p;}
function q($s,$a=[]){$t=db()->prepare($s);$t->execute($a);return $t;}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES);}
function me(){return $_SESSION['u']??null;}
function need(...$r){if(!me()){header('Location: login.php');exit;}if($r&&!in_array(me()['role'],$r))die('Akses ditolak');}
function tp(){return q("SELECT id FROM tahun_pelajaran WHERE aktif=1 LIMIT 1")->fetchColumn();}
function setting($k){static $s;if(!$s)$s=q("SELECT kunci,nilai FROM pengaturan")->fetchAll(PDO::FETCH_KEY_PAIR);return $s[$k]??'';}
function statusPoin($p){foreach([['batas_berat','Sanksi Berat / Keputusan Sekolah'],['batas_sp','Surat Peringatan'],['batas_panggilan','Panggilan Orang Tua'],['batas_pembinaan','Pembinaan']] as [$k,$l])if($p>=(int)setting($k))return $l;return 'Aman';}
function csrf(){$_SESSION['csrf']=$_SESSION['csrf']??bin2hex(random_bytes(16));return "<input type=hidden name=csrf value='{$_SESSION['csrf']}'>";}
