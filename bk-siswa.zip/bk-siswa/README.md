# Sistem BK & Kesiswaan (PHP 8+ / MySQL)
1. Salin folder ke htdocs (XAMPP) -> htdocs/bk-siswa
2. phpMyAdmin -> Import -> database.sql
3. Sesuaikan config.php bila user/password MySQL berbeda
4. Buka http://localhost/bk-siswa
Akun (password: password): admin | kesiswaan | wali1  -> GANTI setelah login pertama.
