<?php require 'config.php';require 'inc/crud.php';need();
$m=$_GET['m']??'dashboard';$raw=false;
if($_SERVER['REQUEST_METHOD']=='POST'&&!hash_equals($_SESSION['csrf']??'',$_POST['csrf']??''))die('CSRF tidak valid');
$mods=require 'modules.php';
$pages=['dashboard'=>[],'profil'=>[],'monitoring'=>['admin','kesiswaan','wali_kelas'],'laporan'=>[],'pengaturan'=>['admin'],'surat'=>[],'import'=>['admin']];
ob_start();
if(isset($mods[$m])){need(...$mods[$m]['roles']);crud($mods[$m]);}
elseif(isset($pages[$m])){need(...$pages[$m]);require "pages/$m.php";}
else echo 'Halaman tidak ada';
$body=ob_get_clean();
if($raw){echo $body;exit;}
require 'inc/head.php';echo $body;echo '</main></div></body></html>';
